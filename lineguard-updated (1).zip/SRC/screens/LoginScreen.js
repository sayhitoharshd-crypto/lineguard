import React, { useState } from 'react';
import { View, Text, Image, ScrollView, Alert, TextInput, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../firebase/AuthContext';
import { Btn } from '../components/ui';
import { G, C } from '../theme';

export default function LoginScreen({ onBrowse }) {
  const { signInGoogle, signInAnon, signInEmail, signUpEmail, googleReady } = useAuth();
  const [busy, setBusy] = useState('');
  const [authMode, setAuthMode] = useState('menu'); // 'menu' | 'email_login' | 'email_signup'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const run = async (k, fn) => {
    setBusy(k);
    try {
      await fn();
    } catch (e) {
      Alert.alert('Authentication Failed', String(e?.message || e));
    }
    setBusy('');
  };

  const handleEmailAuth = () => {
    if (!email.trim() || !password) {
      Alert.alert('Missing Details', 'Please enter your email and password.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Short Password', 'Password must be at least 6 characters.');
      return;
    }
    if (authMode === 'email_signup') {
      run('email', () => signUpEmail(email, password));
    } else {
      run('email', () => signInEmail(email, password));
    }
  };

  return (
    <LinearGradient
      colors={G.main}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={{
            flexGrow: 1,
            justifyContent: 'space-between',
            padding: 24,
          }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={{ alignItems: 'center', marginTop: 24 }}>
            <Image
              source={require('../../Assets/icon.png')}
              style={{
                width: 90,
                height: 90,
                borderRadius: 26,
                marginBottom: 14,
              }}
            />
            <Text
              style={{
                fontSize: 36,
                fontWeight: '900',
                color: '#fff',
                letterSpacing: -1.5,
              }}
            >
              LineGuard
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: 'rgba(255,255,255,0.88)',
                fontWeight: '700',
                marginTop: 6,
                textAlign: 'center',
                lineHeight: 20,
              }}
            >
              Report line cutters silently.{'\n'}No shouting. No arguments.
            </Text>
          </View>

          <View
            style={{
              backgroundColor: 'rgba(255,255,255,0.15)',
              borderRadius: 18,
              padding: 14,
              marginVertical: 16,
              borderWidth: 1,
              borderColor: 'rgba(255,255,255,0.25)',
            }}
          >
            <Text
              style={{
                color: '#fff',
                fontWeight: '900',
                fontSize: 12,
                marginBottom: 5,
              }}
            >
              ⭐ Reputation keeps reports honest
            </Text>
            <Text
              style={{
                color: 'rgba(255,255,255,0.8)',
                fontWeight: '700',
                fontSize: 11,
                lineHeight: 16,
              }}
            >
              Start with 100 points. Dismissed reports cost 20. Confirmed ones
              earn 10. Below 50 you're paused.
            </Text>
          </View>

          {authMode !== 'menu' ? (
            <View
              style={{
                backgroundColor: 'rgba(255,255,255,0.18)',
                borderRadius: 20,
                padding: 18,
                marginBottom: 12,
                borderWidth: 1,
                borderColor: 'rgba(255,255,255,0.3)',
              }}
            >
              <Text
                style={{
                  color: '#fff',
                  fontSize: 18,
                  fontWeight: '900',
                  marginBottom: 12,
                  textAlign: 'center',
                }}
              >
                {authMode === 'email_signup' ? 'Create Account' : 'Sign In with Email'}
              </Text>

              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="Email address"
                placeholderTextColor="rgba(255,255,255,0.6)"
                keyboardType="email-address"
                autoCapitalize="none"
                style={{
                  backgroundColor: 'rgba(255,255,255,0.95)',
                  borderRadius: 14,
                  padding: 12,
                  fontSize: 14,
                  color: C.text,
                  fontWeight: '700',
                  marginBottom: 10,
                }}
              />

              <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="Password (min 6 characters)"
                placeholderTextColor="rgba(255,255,255,0.6)"
                secureTextEntry
                style={{
                  backgroundColor: 'rgba(255,255,255,0.95)',
                  borderRadius: 14,
                  padding: 12,
                  fontSize: 14,
                  color: C.text,
                  fontWeight: '700',
                  marginBottom: 14,
                }}
              />

              <Btn
                title={authMode === 'email_signup' ? 'Sign Up' : 'Sign In'}
                onPress={handleEmailAuth}
                busy={busy === 'email'}
              />

              <TouchableOpacity
                onPress={() =>
                  setAuthMode(
                    authMode === 'email_signup' ? 'email_login' : 'email_signup'
                  )
                }
                style={{ marginTop: 6, marginBottom: 8, alignItems: 'center' }}
              >
                <Text
                  style={{
                    color: '#fff',
                    fontWeight: '800',
                    fontSize: 12,
                    textDecorationLine: 'underline',
                  }}
                >
                  {authMode === 'email_signup'
                    ? 'Already have an account? Sign In'
                    : "Don't have an account? Create one"}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setAuthMode('menu')}
                style={{ alignItems: 'center', marginTop: 4 }}
              >
                <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, fontWeight: '700' }}>
                  ← Back to other options
                </Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View>
              <Btn
                title="Continue with Email"
                onPress={() => setAuthMode('email_login')}
              />

              <Btn
                kind="outline"
                title="Continue with Google"
                onPress={() => {
                  if (!googleReady) {
                    Alert.alert(
                      'Google login',
                      'Google OAuth client ID is not configured yet. You can sign in with Email or use Anonymously meanwhile.'
                    );
                    return;
                  }
                  run('g', signInGoogle);
                }}
                busy={busy === 'g'}
              />

              <Btn
                kind="outline"
                title="Use anonymously"
                onPress={() => run('a', signInAnon)}
                busy={busy === 'a'}
              />

              {onBrowse ? (
                <Btn
                  kind="ghost"
                  title="Browse as guest"
                  onPress={onBrowse}
                />
              ) : null}

              <Text
                style={{
                  color: 'rgba(255,255,255,0.6)',
                  fontSize: 11,
                  textAlign: 'center',
                  fontWeight: '600',
                  marginTop: 6,
                }}
              >
                Your account name is hidden from public report cards.
              </Text>
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}
